const { Telegraf, Markup } = require("telegraf");
const axios = require("axios");
const cheerio = require("cheerio");
const FormData = require("form-data");
const fs = require("fs");
const obfuscateCode = require('./toolsobf');
const fetch = require("node-fetch");
const yts = require("yt-search");
const path = require('path');
const config = require("./setting/settings")

//========= SETTINGS ============
// Masukkan token bot Telegram
const bot = new Telegraf(config.TOKEN);
const thumbnailUrl = config.THUMBNAIL; 
const OWNER_ID = config.IDTELE; // M
const ownerId = config.idtele;

//========= BATAS SETTINGS ============
//======== DATABASE=========
const USERS_PREMIUM_FILE = 'userspremium.json';

// File tempat daftar grup disimpan
const allowedGroupsFile = 'allowedGroups.json';
// Fungsi untuk memeriksa apakah pengguna adalah pemilik bot
function isOwner(userId) {
    return config.OWNER_ID.includes(userId);
}

// Simpan ID pengguna dalam array
let users = [];

// Muat ID pengguna dari file (jika ada)
if (fs.existsSync("users.json")) {
  users = JSON.parse(fs.readFileSync("users.json"));
}

// Simpan ID pengguna ke file
function saveUsers() {
  fs.writeFileSync("users.json", JSON.stringify(users));
}

// Fungsi untuk menampilkan log keren berwarna saat bot online
function logBotOnline() {
    const botName = chalk.bold.cyan("🔥 APebot🔥"); // Nama bot
    const currentTime = chalk.yellow(new Date().toLocaleString()); // Waktu server

    console.clear();
    console.log(chalk.bgBlue("==========================================="));
    console.log(botName);
    console.log(chalk.bgBlue("==========================================="));
    console.log(chalk.green("🤖 Status         : ") + chalk.bold.green("Online"));
    console.log(chalk.green("📅 Waktu Server   : ") + currentTime);
    console.log(chalk.green("🚀 APebot Siap Melayani Perintah Anda!"));
    console.log(chalk.bgBlue("==========================================="));
    console.log(chalk.blue("💻 telegram: t.me/unbound_7")); // Opsional: info tambahan
    console.log(chalk.bgBlue("==========================================="));
}


async function top4top(buffer, filename) {
  const form = new FormData();
  form.append("file_1_", buffer, filename); // Menambahkan file dengan nama acak
  form.append("submitr", "[ رفع الملفات ]");

  try {
    const response = await axios.post("https://top4top.io/index.php", form, {
      headers: {
        ...form.getHeaders(),
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "User-Agent": "Mozilla/5.0 (BlackBerry; U; BlackBerry 9900; en) AppleWebKit/534.11+ (KHTML, like Gecko) Version/7.0.0.585 Mobile Safari/534.11+",
      },
    });

    const $ = cheerio.load(response.data);
    const result = $("div.alert.alert-warning > ul > li > span").find("a").attr("href") || "gagal";
    if (result === "gagal") {
      return { status: "error", result: "File tidak diizinkan atau coba file lain" };
    } else {
      return { status: "sukses", result };
    }
  } catch (error) {
    console.error("Error uploading to Top4Top:", error);
    return { status: "error", result: "Gagal mengunggah file" };
  }
}

async function downloadFile(fileLink) {
    try {
        const response = await axios.get(fileLink);
        return response.data;
    } catch (error) {
        console.error('Error downloading the file:', error);
        throw new Error('Failed to download the file');
    }
}


// Fungsi untuk mengunduh video/audio dari YouTube
async function ytdl(url) {
    const response = await fetch("https://shinoa.us.kg/api/download/ytdl", {
        method: "POST",
        headers: {
            accept: "*/*",
            api_key: "free",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            text: url,
        }),
    });

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
}

// Fungsi untuk mengonversi jumlah ke format rupiah
function toRupiah(amount) {
    return amount.toLocaleString('id-ID', { style: 'currency', currency: 'IDR' });
}

// Fungsi delay/sleep
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
// Fungsi untuk memeriksa apakah pengguna adalah pemilik bot
function isOwner(userId) {
    return config.OWNER_ID.includes(userId);
}
// Fungsi untuk membisukan pengguna
async function muteUser(ctx, userId, duration) {
    try {
        // Mengatur batas waktu mute dalam hitungan detik
        const untilDate = duration ? Math.floor(Date.now() / 1000) + duration : 0;

        await ctx.telegram.restrictChatMember(ctx.chat.id, userId, {
            can_send_messages: false,
            until_date: untilDate
        });

        const timeMessage = duration ? `selama ${duration} detik` : "secara permanen";
        ctx.reply(`🚫 Pengguna berhasil dibisukan ${timeMessage}.`);
    } catch (error) {
        console.log("Gagal membisukan pengguna:", error);
        ctx.reply("❌ Terjadi kesalahan saat mencoba membisukan pengguna.");
    }
}

// Fungsi untuk mengaktifkan kembali izin kirim pesan pengguna
async function unmuteUser(ctx, userId) {
    try {
        await ctx.telegram.restrictChatMember(ctx.chat.id, userId, {
            can_send_messages: true,
            can_send_media_messages: true,
            can_send_other_messages: true,
            can_add_web_page_previews: true
        });

        ctx.reply("✅ Pengguna berhasil di-unmute dan dapat mengirim pesan kembali.");
    } catch (error) {
        console.log("Gagal membatalkan mute pengguna:", error);
        ctx.reply("❌ Terjadi kesalahan saat mencoba meng-unmute pengguna.");
    }
}
async function downloadFile(fileLink) {
    try {
        const response = await axios.get(fileLink);
        return response.data;
    } catch (error) {
        console.error('Error downloading the file:', error);
        throw new Error('Failed to download the file');
    }
}

// File tempat daftar pengguna disimpan
const userDatabaseFile = 'users.json';

// Muat database pengguna dari file
let userDatabase = [];
if (fs.existsSync(userDatabaseFile)) {
    userDatabase = JSON.parse(fs.readFileSync(userDatabaseFile));
}

// Fungsi untuk menyimpan database pengguna ke file
function saveUserDatabase() {
    fs.writeFileSync(userDatabaseFile, JSON.stringify(userDatabase, null, 2));
}

// Middleware untuk menambah pengguna baru ke database
bot.use((ctx, next) => {
    const userId = ctx.from.id;

    // Tambahkan pengguna baru ke database jika belum ada
    if (!userDatabase.includes(userId)) {
        userDatabase.push(userId);
        saveUserDatabase();  // Simpan ke file setiap kali ada pengguna baru
        console.log(`Pengguna baru ditambahkan: ${userId}`);
    }
    
    return next();
});

//==========BATASSS APebot================
bot.command("tourl", async (ctx) => {
console.log(`Perintah diterima: /tourl dari pengguna: ${ctx.from.username || ctx.from.id}`);
  const replyMessage = ctx.message.reply_to_message;

  // Cek apakah pesan yang dibalas adalah foto
  if (replyMessage && replyMessage.photo) {
    try {
      const photo = replyMessage.photo.pop(); // Mengambil resolusi tertinggi
      const fileId = photo.file_id;

      // Mendapatkan link unduh dari Telegram
      const fileLink = await ctx.telegram.getFileLink(fileId);
      
      // Mengunduh file sebagai buffer menggunakan axios
      const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
      const buffer = Buffer.from(response.data, "binary");
      const filename = `${Math.floor(Math.random() * 10000)}.jpg`; // Menyusun nama file

      // Mengunggah file ke Top4Top
      const uploadResult = await top4top(buffer, filename);
      const { result, status } = uploadResult;
      
      // Menyusun pesan tanggapan
      const caption = `[ ${status.toUpperCase()} ]

📮 L I N K :
${result}
📊 S I Z E : ${buffer.length} Byte
`;
      ctx.reply(caption); // Mengirim tanggapan ke pengguna
    } catch (error) {
      console.error("Error:", error);
      ctx.reply("Terjadi kesalahan. Coba lagi nanti.");
    }
  } else {
    ctx.reply("Balas pesan gambar dengan menggunakan perintah /tourl untuk mengonversinya menjadi link.");
  }
});



// Fungsi untuk mendapatkan video TikTok tanpa watermark
async function tiktok(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const encodedParams = new URLSearchParams();
      encodedParams.set("url", query);
      encodedParams.set("hd", "1");

      const response = await axios({
        method: "POST",
        url: "https://tikwm.com/api/",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "Cookie": "current_language=en",
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
        },
        data: encodedParams,
      });

      const videos = response.data.data;
      const result = {
        title: videos.title,
        cover: videos.cover,
        origin_cover: videos.origin_cover,
        no_watermark: videos.play,
        watermark: videos.wmplay,
        music: videos.music,
      };
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}

// Command /tiktok
bot.command("tiktok", async (ctx) => {
console.log(`Perintah diterima: /tiktok dari pengguna: ${ctx.from.username || ctx.from.id}`);
  const args = ctx.message.text.split(" ").slice(1);
  if (args.length === 0) return ctx.reply("☘️ *Link TikTok-nya Mana?*");

  const url = args[0];
  const urlRegex = /^(https?:\/\/)?([\w.-]+)+(:\d+)?(\/\S*)?$/;  // Pemeriksaan URL yang lebih umum

  if (!urlRegex.test(url)) {
    return ctx.reply("⚠️ *Itu Bukan Link Yang Benar*");
  }

  ctx.reply("⏳ Tunggu sebentar, sedang mengambil video...");

  try {
    const res = await tiktok(url);
    
    // Mengirim video tanpa watermark
    await ctx.replyWithVideo({ url: res.no_watermark }, { caption: `🎬 *Judul*: ${res.title}` });
    
    // Mengirim audio dari video
    await ctx.replyWithAudio({ url: res.music }, { title: `tiktok_audio.mp3` });
    
  } catch (error) {
    console.error(error);
    ctx.reply("⚠️ Terjadi kesalahan saat mengambil video TikTok. Coba lagi nanti.");
  }
});

// Perintah /start
bot.command("start", (ctx) => {
    const userId = ctx.from.id;
  const username = ctx.from.username || "tanpa username";
      // Mengecek apakah pengguna sudah terdaftar atau belum
  const isNewUser = !users.includes(userId);

  // Menyimpan ID pengguna jika belum terdaftar
  if (isNewUser) {
    users.push(userId);
    saveUsers();
  }
    
console.log(`Perintah diterima: /start dari pengguna: ${ctx.from.username || ctx.from.id}`);
  ctx.reply(
    "👋 Selamat datang di bot kami! Pilih fitur yang ingin Anda gunakan di bawah ini:",
    Markup.inlineKeyboard([
      [Markup.button.callback("🔥 Owner Menu", "owner_menu")],
      [Markup.button.callback("🧢 Tourl", "tourl")],
      [Markup.button.callback("📥 Download Menu", "download_menu")],
      [Markup.button.callback("☠️ Obf Menu", "obf_menu")],
      [Markup.button.callback("👥 Grup Menu", "grup_menu")],
      [Markup.button.callback("🗣️ Owner Bot", "owner_bot")]
        
    ])
  );

  // Kirim notifikasi ke owner hanya jika pengguna baru
  if (isNewUser) {
    bot.telegram.sendMessage(
      OWNER_ID,
      `👤 Pengguna baru telah memulai bot:\n\nID: ${userId}\nUsername: @${username}`
    );
  }
});
bot.action("grup_menu", (ctx) => {
  ctx.answerCbQuery(); // Memberi umpan balik bahwa tombol ditekan
  ctx.reply("☠️ Fitur Ini Khusus Grup: Ketik /grupmenu");
});

bot.action("obf_menu", (ctx) => {
  ctx.answerCbQuery(); // Memberi umpan balik bahwa tombol ditekan
  ctx.reply("☠️ Fitur Ini Untuk Enc File: Ketik /obfmenu untuk melihat menu enc");
});

// Handler untuk tombol "Broadcast"
bot.action("owner_menu", (ctx) => {
  ctx.answerCbQuery(); // Memberi umpan balik bahwa tombol ditekan
  ctx.reply("🔥 Fitur Ini Only Ownerku: ketik /ownermenu untuk melihat list fitur nya.");
  // Anda bisa menambahkan logika broadcast di sini atau memanggil handler lain
});

bot.action("owner_bot", (ctx) => {
  ctx.answerCbQuery(); // Memberi umpan balik bahwa tombol ditekan
  ctx.reply("💌 INI OWNER KU SEKALIGUS PEMBUAT SCRIPT NYA @unbound_7");
  // Anda bisa menambahkan logika broadcast di sini atau memanggil handler lain
});
// Handler untuk tombol "Play Music"
bot.action("tourl", (ctx) => {
  ctx.answerCbQuery();
  ctx.reply("🧢 Fitur Tourl Image: Reply Image ketik /tourl ");
  // Panggil handler tiurl image
});

// Handler untuk tombol "Download TikTok"
bot.action("download_menu", (ctx) => {
  ctx.answerCbQuery();
  ctx.reply("📥 Fitur Download : ketik /downloadmenu untuk menampilkan all fitur download .");
  // Panggil handler download tiktok yang sudah dibuat
});

//======= BATAS FITUR========//

// Command broadcast, hanya untuk pemilik bot
bot.command("bc", async (ctx) => {
    // Mengecek apakah pengguna adalah pemilik
    if (ctx.from.id.toString() !== OWNER_ID) {
        return ctx.reply("⚠️ Hanya pemilik bot yang dapat menggunakan fitur ini.");
    }

    // Mengecek apakah ada pesan yang dibalas untuk diteruskan
    if (!ctx.message.reply_to_message) {
        return ctx.reply("⚠️ Balas pesan yang ingin Anda teruskan ke semua pengguna.");
    }

    // Memproses pesan yang akan diteruskan ke semua pengguna
    const messageToForward = ctx.message.reply_to_message.message_id;
    const chatId = ctx.message.chat.id;

    ctx.reply("🔄 Sedang meneruskan pesan ke semua pengguna...");

    for (let userId of users) {
        try {
            await bot.telegram.forwardMessage(userId, chatId, messageToForward);
        } catch (error) {
            console.log(`Tidak dapat meneruskan pesan ke ${userId}:`, error.message);
        }
    }
    
    

    ctx.reply(`✅ Pesan telah dikirim ke pengguna total ${users.length} pengguna..`);
});

//======= BATAS FITUR========//
//FITUR ENC

// Load or initialize premium users
let usersPremium = {};
if (fs.existsSync(USERS_PREMIUM_FILE)) {
    usersPremium = JSON.parse(fs.readFileSync(USERS_PREMIUM_FILE, 'utf8'));
} else {
    fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify({}));
}

// Initialize userSessions
let userSessions = {};

bot.command('obfmenu', (ctx) => {
console.log(`Perintah diterima: /obfmenu dari pengguna: ${ctx.from.username || ctx.from.id}`);
    const menuText = `
\`\`\`Obfuscation Menu
1. /obf1 - Var [HardObf!]
2. /obf2 - Var [ExtremeObf!]
3. /obf3 - DeadCode [ExtremeObf!]
4. /obf4 - EncCode [ExtremeObf!!]
5. /obf5 - ABCD [HardObf!]
6. /obf6 - Name [ExtremeObf!!]
7. /obf7 - Name [ExtremeObf!!]
8. /obf8 - Name [ExtremeObf!]
9. /obf9 - Crass [HardObf!]
👽AMANKAN SCRIPT MU SEGARA!!!

📄 Kirim file .js Anda setelah memilih jenis Obfuscation.\`\`\`
    `;

    ctx.reply(menuText, { parse_mode: 'Markdown' });
});

//======= BATAS FITUR========//

bot.command('ownermenu', (ctx) => {
console.log(`Perintah diterima: /ownermenu dari pengguna: ${ctx.from.username || ctx.from.id}`);
    const menuText = `
\`\`\`OWNER_MENU

1. /backup
2. /addprem

MASIH TAHAP PENGAMBANGAN\`\`\`
`;
ctx.reply(menuText, { parse_mode: 'Markdown' });
});

//======= BATAS FITUR========//

bot.command('downloadmenu', (ctx) => {
console.log(`Perintah diterima: /downloadmenu dari pengguna: ${ctx.from.username || ctx.from.id}`);
    const menuText = `
\`\`\`DOWNLOAD_MENU

1. /tiktok
2. /play
3. /igvid

MASIH TAHAP PENGAMBANGAN\`\`\`
`;
ctx.reply(menuText, { parse_mode: 'Markdown' });
});

//======= BATAS FITUR========//
bot.command('grupmenu', (ctx) => {
console.log(`Perintah diterima: /grupmenu dari pengguna: ${ctx.from.username || ctx.from.id}`);
    const menuText = `
\`\`\`GROUP_MENU

1. /mute
2. /unmute

MASIH TAHAP PENGAMBANGAN\`\`\`
`;
ctx.reply(menuText, { parse_mode: 'Markdown' });
});


bot.command('obf1', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD. buy 1k 1limit ke @Rust4nXD');
    }

    userSessions[userId] = { obfuscationType: 'obf1' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Rename All Variable Var).');
});

// Command for obfuscation type obf2 (Hexadecimal Anti Dec)
bot.command('obf2', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD');
    }

    userSessions[userId] = { obfuscationType: 'obf2' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Hexadecimal Anti Dec).');
});

// Command for obfuscation type obf3 (Random Deadcode)
bot.command('obf3', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD.');
    }

    userSessions[userId] = { obfuscationType: 'obf3' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Random Deadcode).');
});

// Command for obfuscation type obf4 (Return Obfuscation)
bot.command('obf4', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD.');
    }

    userSessions[userId] = { obfuscationType: 'obf4' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation.');
});

//mangled
bot.command('obf5', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD.');
    }

    userSessions[userId] = { obfuscationType: 'obf5' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Type 5).');
});

bot.command('obf6', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD');
    }

    userSessions[userId] = { obfuscationType: 'obf6' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Type 6).');
});

bot.command('obf7', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD');
    }

    userSessions[userId] = { obfuscationType: 'obf7' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Type 7).');
});

bot.command('obf8', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD');
    }

    userSessions[userId] = { obfuscationType: 'obf8' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Type 8).');
});

bot.command('obf9', (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD.');
    }

    userSessions[userId] = { obfuscationType: 'obf9' };
    ctx.reply('📄 Silakan kirim file .js Anda untuk Obfuscation (Type 9).');
});

//======= BATAS FITUR========//

// Check premium status
bot.command('status', (ctx) => {
    const userId = ctx.from.id.toString();

    if (isPremium(userId)) {
        const remainingDays = Math.ceil((usersPremium[userId].premiumUntil - Date.now()) / (24 * 60 * 60 * 1000));
        ctx.reply(`📅 anda punya ${remainingDays} limit premium`);
    } else {
        ctx.reply('❌ Anda tidak memiliki akses premium. buy 1k 1limit ke @Rust4nXD');
    }
});

//======= BATAS FITUR========//

bot.command('addprem', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    const userId = args[0];
    const days = parseInt(args[1]);

    if (!isOwner(ctx.from.id)) {
        return ctx.reply('❌ Command Khusus Owner');
    }

    if (!userId || isNaN(days)) {
        return ctx.reply('❗ Format salah. Gunakan: /addprem <user_id> <jumlah_limit>');
    }

    let messageToUser;
    if (!usersPremium[userId]) {
        // Jika belum premium, berikan status premium
        usersPremium[userId] = { premiumUntil: Date.now() + days * 24 * 60 * 60 * 1000 };
        messageToUser = `Selamat! Anda telah menjadi pengguna premium selama ${days} limit 🎉. Nikmati fitur eksklusif!`;
        ctx.reply(`✅ User ${userId} telah diberikan ${days} limit premium.`);
    } else {
        // Jika sudah premium, berikan notifikasi dan tambahkan masa aktif
        const currentPremiumUntil = usersPremium[userId].premiumUntil;
        const newPremiumUntil = currentPremiumUntil + days * 24 * 60 * 60 * 1000;
        usersPremium[userId].premiumUntil = newPremiumUntil;

        const remainingDays = Math.floor((currentPremiumUntil - Date.now()) / (24 * 60 * 60 * 1000));
        messageToUser = `Anda telah diperpanjang status premium selama ${days} limit. Total premium aktif hingga ${new Date(newPremiumUntil).toLocaleDateString()} 🎉`;
        ctx.reply(`⚠️ User ${userId} sudah memiliki status premium selama ${remainingDays} limit lagi. Menambah ${days} limit.`);
    }

    fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify(usersPremium));

    // Kirim notifikasi ke calon pengguna premium
    try {
        await bot.telegram.sendMessage(userId, messageToUser);
    } catch (error) {
        ctx.reply(`❗ Gagal mengirim notifikasi ke user ${userId}. Pastikan mereka telah memulai bot.`);
        console.error(`Error sending message to ${userId}: ${error.message}`);
    }
});
// Reduce premium days function
function reducePremiumDays(userId) {
    if (usersPremium[userId] && usersPremium[userId].premiumUntil > Date.now()) {
        usersPremium[userId].premiumUntil -= 24 * 60 * 60 * 1000; // Reduce by 1 day
        fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify(usersPremium));
    } else if (usersPremium[userId]) {
        delete usersPremium[userId]; // Remove user from premium list
        fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify(usersPremium));
    }
}

// Check if user is premium
function isPremium(userId) {
    return usersPremium[userId] && usersPremium[userId].premiumUntil > Date.now();
}

// Check if user is owner
function isOwner(userId) {
    return userId.toString() === OWNER_ID;
}

// Interval to reduce premium days
setInterval(() => {
    const now = new Date();
    if (now.getHours() === 0 && now.getMinutes() === 0) {
        for (const userId in usersPremium) {
            reducePremiumDays(userId);
        }
    }
}, 60 * 60 * 1000); // Check every hour

// Handle document uploads for premium users
bot.on('document', async (ctx) => {
    const userId = ctx.from.id.toString();

    if (!isPremium(userId)) {
        return ctx.reply('❌ Fitur ini hanya tersedia untuk pengguna premium.');
    }

    const fileName = ctx.message.document.file_name;

    if (!fileName.endsWith('.js')) {
        return ctx.reply('❌ Silakan kirim file dengan ekstensi .js.');
    }

    if (!userSessions[userId] || !userSessions[userId].obfuscationType) {
        return ctx.reply('❌ Silakan pilih jenis obfuscation terlebih dahulu menggunakan salah satu perintah.');
    }

    const obfuscationType = userSessions[userId].obfuscationType;

    // Reduce premium days
    reducePremiumDays(userId);

    await handleDocumentObfuscation(ctx, obfuscationType);
});

async function handleDocumentObfuscation(ctx, option) {
    const fileId = ctx.message.document.file_id;
    const loadingMessage = await ctx.reply('🚧 Preparing obfuscation...');

    try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const code = await downloadFile(fileLink);

        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessage.message_id, undefined, '🔄 Encrypting...');
        const obfuscatedCode = await obfuscateCode(code, option);

        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessage.message_id, undefined, '🎉 Obfuscation complete! Sending file...');
        await ctx.replyWithDocument({ source: Buffer.from(obfuscatedCode), filename: 'obfuscated.js' }, {
            caption: `Tools Obf: ${option}\n@Rust4nXD`,
            parse_mode: 'Markdown'
        });

    } catch (error) {
        console.error('Kesalahan selama proses obfuscation', error);
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessage.message_id, undefined, '❌ Terjadi kesalahan saat kebingungan obfuscation.');
    }
}
 
//======= BATAS FITUR========//

// Perintah untuk mencari dan mengunduh audio YouTube
bot.command("play", async (ctx) => {
    const text = ctx.message.text.split(" ").slice(1).join(" ");
    if (!text) {
        return ctx.reply("Contoh penggunaan: /play [judul video]");
    }

    // Menampilkan pesan loading saat mencari video
    const waitMessage = await ctx.reply(`Searching.. [ ${text} ] 🔍`);

    try {
        const search = await yts(text);
        const download = search.videos[Math.floor(Math.random() * search.videos.length)];
        if (!download) {
            return ctx.reply("Video tidak ditemukan. Coba judul lain.");
        }

        const { url } = download;
        const result = await ytdl(url);

        // Mengedit pesan loading menjadi status mengirim
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            waitMessage.message_id,
            undefined,
            `Mengirim.. [ ${text} ] 🎶`
        );

        // Mengirim audio ke pengguna
        await ctx.replyWithAudio({
            url: result.data.mp3,
            filename: `${download.title}.mp3`,
        }, {
            caption: `🎧 Berikut adalah audio untuk *${download.title}*`,
            parse_mode: "Markdown"
        });

    } catch (error) {
        console.error("Error:", error);
        ctx.reply("Maaf, terjadi kesalahan saat mencoba memproses permintaan Anda.");
    }
});
    
//======= BATAS FITUR========//

//======= BATAS FITUR========//

// Event ketika ada pengguna yang bergabung ke dalam grup
bot.on("new_chat_members", (ctx) => {
 const username = ctx.from.username || "tanpa username";
    const newMembers = ctx.message.new_chat_members;
    newMembers.forEach((member) => {
        const firstName = member.first_name || "Pengguna";
        const lastName = member.last_name ? ` ${member.last_name}` : "";

        // Mengirim pesan selamat datang dengan thumbnail dan tombol
        ctx.replyWithPhoto(thumbnailUrl, {
            caption: `👋 Selamat datang, @${username}!\n\nTerima kasih sudah bergabung dengan grup..\nADMIN UTAMA @Rust4nXD`,
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.url("📖 TESTI ADMIN", "https://t.me/unbound_7")],
                [Markup.button.url("👺 ADMIN UTAMA", "https://t.me/unbound_7")]
            ])
        });
    });
});

//======= BATAS FITUR========//

// Event ketika ada pengguna yang keluar dari grup
bot.on("left_chat_member", (ctx) => {
 const username = ctx.from.username || "tanpa username";
    const leftMember = ctx.message.left_chat_member;
    const firstName = leftMember.first_name || "Pengguna";
    const lastName = leftMember.last_name ? ` ${leftMember.last_name}` : "";
    ctx.reply(`👋 Selamat jalan, @${username}. Semoga sukses!`);
});

// Handle button callback untuk "Mulai Percakapan"
bot.action("start_chat", (ctx) => {
    ctx.reply("💬 Silakan mulai percakapan Anda di grup ini. Jangan lupa untuk membaca rules grup ini.");
});

//======= BATAS FITUR========//

// Perintah /mute untuk membisukan anggota
bot.command("mute", async (ctx) => {
    // Periksa apakah pengguna yang menjalankan perintah adalah admin
    const chatMember = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);
    if (!["administrator", "creator"].includes(chatMember.status)) {
        return ctx.reply("⚠️ Hanya admin yang dapat menggunakan perintah ini.");
    }

    // Mendapatkan user yang di-*mention* dan durasi mute
    const reply = ctx.message.reply_to_message;
    const args = ctx.message.text.split(" ");
    const duration = parseInt(args[1]); // Durasi mute dalam detik (opsional)

    if (!reply) {
        return ctx.reply("⚠️ Balas pesan pengguna yang ingin Anda bisukan.");
    }

    // Membisukan pengguna yang di-*reply*
    const userId = reply.from.id;
    await muteUser(ctx, userId, duration);
});

//======= BATAS FITUR========//

// Perintah /unmute untuk mengaktifkan kembali izin kirim pesan anggota
bot.command("unmute", async (ctx) => {
    // Periksa apakah pengguna yang menjalankan perintah adalah admin
    const chatMember = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);
    if (!["administrator", "creator"].includes(chatMember.status)) {
        return ctx.reply("⚠️ Hanya admin yang dapat menggunakan perintah ini.");
    }

    // Mendapatkan pengguna yang di-*reply*
    const reply = ctx.message.reply_to_message;
    if (!reply) {
        return ctx.reply("⚠️ Balas pesan pengguna yang ingin Anda unmute.");
    }

    // Meng-unmute pengguna yang di-reply
    const userId = reply.from.id;
    await unmuteUser(ctx, userId);
});

//=======batas=======
bot.command('backup', (ctx) => {
    if (ctx.from.id === ownerId) {
        const backupFileName = `backup_users_${Date.now()}.json`;
        const backupFilePath = path.join(__dirname, backupFileName);

        // Salin file database ke file backup dengan nama unik
        fs.copyFile(userDatabaseFile, backupFilePath, async (err) => {
            if (err) {
                console.error('Gagal membuat backup:', err);
                return ctx.reply('Gagal membuat backup.');
            }

            try {
                // Kirim file backup ke pemilik bot
                await ctx.replyWithDocument({ source: backupFilePath });
                ctx.reply(`Backup berhasil dibuat dan dikirim sebagai ${backupFileName}`);
                
                // Hapus file backup setelah dikirim (opsional)
                fs.unlinkSync(backupFilePath);
            } catch (error) {
                console.error('Gagal mengirim file backup:', error);
                ctx.reply('Backup berhasil dibuat tetapi gagal dikirim.');
            }
        });
    } else {
        ctx.reply("Anda tidak memiliki izin untuk menggunakan perintah ini.");
    }
});

bot.command("igvid", async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1).join(" ");
    if (!args) return ctx.reply("Anda perlu memberikan URL video atau reel Instagram.");

    let res;
    try {
        res = await fetch(`https://aemt.uk.to/download/igdl?url=${encodeURIComponent(args)}`);
    } catch (error) {
        return ctx.reply(`Terjadi kesalahan: ${error.message}`);
    }

    let api_response;
    try {
        api_response = await res.json();
    } catch (error) {
        return ctx.reply(`Gagal membaca respons dari API: ${error.message}`);
    }

    if (!api_response || !api_response.result || api_response.result.length === 0) {
        return ctx.reply("Tidak ada video atau gambar yang ditemukan, atau respons API tidak valid.");
    }

    try {
        const mediaData = api_response.result[0]; // Mengambil elemen pertama dari hasil
        const mediaURL = mediaData.url;
        const cap = "Berikut videonya:";

        // Mengirimkan video ke pengguna dengan caption
        await ctx.replyWithVideo({ url: mediaURL }, { caption: cap });
    } catch (error) {
        return ctx.reply(`Gagal mengirim media: ${error}`);
    }
});

// Jalankan bot dan tampilkan log keren saat bot aktif
bot.launch().then(() => {
    logBotOnline();
});


