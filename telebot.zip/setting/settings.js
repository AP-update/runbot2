module.exports = {
//==========SETTINGS BOT MU ===========
    TOKEN: '7753308567:AAFsj2OcBa1TuGpkYyOxZARw5PVapXALMoM', // Token bot Telegram Anda
    IDTELE: '1751668585', //GANTI DENGAN ID TELEGRAM MU
    idtele: 1751668585, // ISI JUGA DENGAN ID TELE MU
    THUMBNAIL: 'https://i.ibb.co.com/zxnvdgk/Screenshot-20241126-104509-1.jpg', // ISI FOTO MU YG JELAK

};
