module.exports = {
//==========SETTINGS BOT MU ===========
    TOKEN: '7341036594:AAHQJf83bTUVFqgbalkvk4BM-7wKlSrs9Hk', // Token bot Telegram Anda
    IDTELE: '1751668585', //GANTI DENGAN ID TELEGRAM MU
    idtele: 1751668585, // ISI JUGA DENGAN ID TELE MU
    THUMBNAIL: 'https://i.ibb.co.com/zxnvdgk/Screenshot-20241126-104509-1.jpg', // ISI FOTO MU YG JELAK

};
